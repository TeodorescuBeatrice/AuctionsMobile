﻿namespace AuctionsMobile.Helpers
{
    public enum AuctionType
    {
        English,
        Dutch,
        Blind,
        Vickrey
    }
}
